import { NextResponse } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/auth";
import { prisma, withDbRetry } from "@/lib/prisma";

const defaultTheme = {
  primaryColor: "#481d96", secondaryColor: "#6d28d9", accentColor: "#ff6800",
  accentSoftColor: "#ffb164", backgroundColor: "#ffffff", sectionColor: "#f8f5ff",
  headingColor: "#1e1233", bodyColor: "#6b7280", lineColor: "#e7def7",
  headingFont: "Poppins", bodyFont: "Inter", headingWeight: "700", bodyWeight: "400",
  baseFontSize: 16, headingScale: 1, bodyLineHeight: 1.6,
  radius: 12, containerWidth: 1280, sectionGap: 0,
  buttonRadius: 12, buttonPaddingX: 24, buttonPaddingY: 12,
  buttonPrimaryBg: "#481d96", buttonPrimaryText: "#ffffff",
  buttonSecondaryBg: "#ff6800", buttonSecondaryText: "#ffffff",
};

const sectionKeys = [
  "HERO","SERVICES","ABOUT","MARQUE","PROCESS","TEAM","CASE_STUDIES",
  "PRICING","TESTIMONIALS","CTA"
] as const;

const defaultSectionStyle = {
  enabled: true, backgroundColor: "transparent", textColor: "", headingColor: "",
  eyebrowColor: "", bodyColor: "", borderColor: "transparent",
  paddingTop: 64, paddingBottom: 64, contentAlign: "left",
  titleSize: 48, titleWeight: "700", headingFont: "Poppins", bodyFont: "Inter", bodySize: 16, bodyLineHeight: 1.6,
  titleOffsetX: 0, titleOffsetY: 0, contentOffsetX: 0, contentOffsetY: 0,
  imageObjectPosition: "center", imageOffsetX: 0, imageOffsetY: 0,
  buttonBackground: "", buttonText: "", radius: 0, maxWidth: 1280,
};

const defaultSectionStyles = Object.fromEntries(
  sectionKeys.map((key) => [key, { ...defaultSectionStyle }])
);

const defaultLayout = {
  navbar: {
    logo: "/images/Logo/secondary-logo.webp", ctaLabel: "Get Started", ctaUrl: "/contact",
    exploreLabel: "Explore", mobileSearchPlaceholder: "Search here...",
    navItems: [
      { label: "Home", href: "/" }, { label: "Pages", href: "#" },
      { label: "Services", href: "/services" }, { label: "Portfolios", href: "/portfolios" },
      { label: "Blog", href: "/blog" }, { label: "Contact", href: "/contact" },
    ],
    backgroundColor: "#ffffff", textColor: "#481d96", activeColor: "#ff6800",
    ctaBackground: "#481d96", ctaText: "#ffffff", borderColor: "#e7def7",
    paddingX: 4, paddingY: 1, logoWidth: 120,
  },
  footer: {
    description: "Our mission is to empower businesses of all sizes to thrive in an ever changing marketplace.",
    newsletterTitle: "Subscribe to our newsletter", copyright: "All right reserved.",
    social: [
      { label: "Facebook", href: "https://facebook.com/catalution" },
      { label: "Instagram", href: "https://instagram.com/catalution" },
      { label: "Twitter", href: "https://twitter.com/catalution" },
      { label: "LinkedIn", href: "https://linkedin.com/company/catalution" },
    ],
    backgroundColor: "#f8f5ff", headingColor: "#1e1233", textColor: "#6b7280",
    linkColor: "#481d96", bottomBackground: "#481d96", bottomText: "#dccbff",
    paddingTop: 80, paddingBottom: 80,
  },
  consultantBanner: {
    enabled: true, title: "GET CONSULTANT NOW!", buttonLabel: "Lets talk now", buttonUrl: "/contact",
    backgroundColor: "#481d96", textColor: "#ffffff", buttonBackground: "#ffffff",
    buttonText: "#481d96", paddingTop: 40, paddingBottom: 40,
  },
};

const settingsSchema = z.object({
  key: z.enum(["THEME", "LAYOUT", "SECTION_STYLES"]),
  data: z.record(z.string(), z.any()),
});

async function isAdmin() {
  const session = await getSession();
  return !!session && ["ADMIN", "STAFF"].includes(session.role ?? "");
}

async function getSetting(key: "THEME" | "LAYOUT" | "SECTION_STYLES") {
  const fallback = key === "THEME" ? defaultTheme : key === "LAYOUT" ? defaultLayout : defaultSectionStyles;
  const row = await withDbRetry(() => prisma.siteSettings.findUnique({ where: { key } }));
  if (!row?.data) return fallback;
  if (key === "SECTION_STYLES") return { ...defaultSectionStyles, ...(row.data as object) };
  if (key === "THEME") return { ...defaultTheme, ...(row.data as object) };
  return { ...defaultLayout, ...(row.data as object) };
}

export async function GET(request: Request) {
  const key = new URL(request.url).searchParams.get("key");
  try {
    if (key === "THEME" || key === "LAYOUT" || key === "SECTION_STYLES") {
      const data = await getSetting(key);
      const row = key === "SECTION_STYLES" ? await withDbRetry(() => prisma.siteSettings.findUnique({ where: { key } })) : null;
      return NextResponse.json({ key, data, customized: !!row });
    }
    const [theme, layout, sectionStyles, sectionRow] = await Promise.all([
      getSetting("THEME"), getSetting("LAYOUT"), getSetting("SECTION_STYLES"),
      withDbRetry(() => prisma.siteSettings.findUnique({ where: { key: "SECTION_STYLES" } }))
    ]);
    return NextResponse.json({ theme, layout, sectionStyles, sectionStylesCustomized: !!sectionRow });
  } catch (error) {
    console.error("GET /api/site-settings", error);
    return NextResponse.json({ theme: defaultTheme, layout: defaultLayout, sectionStyles: defaultSectionStyles }, { status: 200 });
  }
}

export async function PUT(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = settingsSchema.parse(await request.json());
    const row = await withDbRetry(() =>
      prisma.siteSettings.upsert({
        where: { key: body.key }, create: { key: body.key, data: body.data },
        update: { data: body.data },
      })
    );
    return NextResponse.json(row);
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: "Invalid settings", details: error.flatten() }, { status: 400 });
    console.error("PUT /api/site-settings", error);
    return NextResponse.json({ error: "Could not save settings" }, { status: 500 });
  }
}
